#include <iostream>

using namespace std;

// дерево
struct tree {
    int value;
    tree *parent;
    tree *left;
    tree *right;
};

// функция создания узла
tree *make_node(int x) {
    tree *temp = new tree;
  
    temp->value = x;
    temp->parent = NULL;
    temp->left = NULL;
    temp->right = NULL;

    return temp;
}

// добавление элемента
void push(tree *&root, int x) {
    tree *temp = make_node(x);

    if (!root) root = temp; // если дерево пустое
    else {
        tree *current = root;

        while (current) { // рекурсивный поиск подходящего места для вставки
            if (temp->value < current->value) {
                if (!current->left) {
                    current->left = temp;
                    temp->parent = current;
                    break;
                }
                else current = current->left;
            } 
            else if (x > current->value) {
                if (!current->right) {
                    current->right = temp;
                    temp->parent = current;
                    break;
                }
                else current = current->right;
            }
        }
    }
}

// рекурсивный вывод дерева
void print_inorder(tree *root) {
    if (root) {
        print_inorder(root->left);

        cout << root->value << " ";
        
        print_inorder(root->right);
    }
}

// функция поиска элемента с заданным значением
tree *find(tree *root, int x) {
    if (!root || root->value == x) return root;
    else if (x < root->value) return find(root->left, x);
    else return find(root->right, x);
}

// минимум в дереве
tree *get_minimum(tree *root) {
    if (!root->left) return root;
    else return get_minimum(root->left);
}

// максимум в дереве
tree *get_maximum(tree *root) {
    if (!root->right) return root;
    else return get_maximum(root->right);
}

// получение предыдущего элемента относительно элемента с заданным значением
tree *get_previous(tree *root, int x) {
    tree *current = find(root, x);

    if (current->left) return get_maximum(current->left);
    else while (current->parent && current->parent->left == current) current = current->parent;

    return current->parent;
}

// аналогичная функция следующего элемента
tree *get_next(tree *root, int x) {
    tree *current = find(root, x);

    if (current->right) return get_minimum(current->right);
    else while (current->parent && current->parent->right == current) current = current->parent;

    return current->parent;
}

// геттер левого сына
tree *get_left(tree *node) {
    return node->left;
}

// геттер правого сына
tree *get_right(tree *node) {
    return node->right;
}

// геттер родителя
tree *get_parent(tree *node) {
    return node->parent;
}

// геттер значения узла
int get_value(tree *node) {
    return node->value;
}

// реализация дерева закончилась
//============================================================================================

// подсчёт количества узлов с левым сыном
int has_left(tree *node) {
    if (!node) return 0;
    else return (get_left(node)?1:0)+has_left(get_left(node))+has_left(get_right(node)); // рекурсивный подсчёт
}

int main() {
    int n, x;
    tree *root = NULL;
    
    cin >> n;

    for (int i = 0; i < n; i++) { // ввод дерева
        cin >> x;
        push(root, x);
    }

    cout << has_left(root) << endl; // вывод

    return 0;
}